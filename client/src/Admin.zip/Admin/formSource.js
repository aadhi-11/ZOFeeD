export const UserInputs=[
    {
        id:1,
        label:"username",
        type:"text",
        placeholder:"midhun"
    },
    {
        id:2,
        label:"Name and surname",
        type:"text",
        placeholder:"santhosh"
    },
    {
        id:3,
        label:"Phone",
        type:"number",
        placeholder:"8912312312"
    },
    {
        id:4,
        label:"Address",
        type:"text",
        placeholder:"Elton st.216 New Delhi"
    },
    {
        id:5,
        label:"state",
        type:"text",
        placeholder:"Kerala"
    }
];

export const productInput=[
    {
        id:1,
        label:"Title",
        type:"text",
        placeholder:"Kuzhimandhi"
    },
    {
        id:2,
        label:"Category",
        type:"text",
        placeholder:"Arabian"
    },
    {
        id:3,
        label:"Description",
        type:"text",
        placeholder:"Description"
    },
    {
        id:4,
        label:"Price",
        type:"text",
        placeholder:"190",

    },
    {
        id:5,
        label:"stock",
        type:"text",
        placeholder:"In Stock"
    }
]