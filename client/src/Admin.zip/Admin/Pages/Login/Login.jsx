import React from 'react'

const Login = () => {
  return (
    <div>
      This is Login
    </div>
  )
}

export default Login
